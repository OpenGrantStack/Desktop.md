import React from 'react';
import { OpenCollectiveEvent } from '@/types';

interface TransactionItemProps {
  event: OpenCollectiveEvent;
}

export default function TransactionItem({ event }: TransactionItemProps) {
  const isCredit = event.data.type === 'credit';
  const isPending = event.data.status === 'pending';
  
  const formatAmount = (amount: number, currency: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency || 'USD',
    }).format(amount);
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getStatusBadge = () => {
    if (isPending) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-yellow-500/20 text-yellow-400">
          <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
          </svg>
          Pending
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-accent-collective/20 text-accent-collective">
        <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
        </svg>
        {event.data.status ? event.data.status.charAt(0).toUpperCase() + event.data.status.slice(1) : 'Completed'}
      </span>
    );
  };

  const getTypeIcon = () => {
    if (event.type === 'expense') {
      return (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      );
    }
    return (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    );
  };

  return (
    <div className="flex items-center space-x-4 p-4 hover:bg-primary-800/50 rounded-lg transition-colors">
      <div className={isCredit ? 'text-accent-collective' : 'text-red-400'}>
        {getTypeIcon()}
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center space-x-2">
          <span className="font-medium text-white truncate">
            {event.data.fromCollective?.name || 'Anonymous'}
          </span>
          <span className="text-gray-500">•</span>
          <span className="text-gray-400 text-sm">{formatTime(event.createdAt)}</span>
        </div>
        <p className="text-sm text-gray-300 mt-0.5 truncate">{event.data.description}</p>
      </div>
      
      <div className="flex items-center space-x-2">
        {getStatusBadge()}
        <span className={isCredit ? 'text-accent-collective font-semibold' : 'text-red-400 font-semibold'}>
          {isCredit ? '+' : '-'}{formatAmount(event.data.amount || 0, event.data.currency || 'USD')}
        </span>
      </div>
    </div>
  );
}
