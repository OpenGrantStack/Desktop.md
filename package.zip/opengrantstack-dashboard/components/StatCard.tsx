import React from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  color: 'github' | 'collective' | 'default';
  trend?: {
    value: number;
    label: string;
  };
}

export default function StatCard({
  title,
  value,
  subtitle,
  icon,
  color,
  trend,
}: StatCardProps) {
  const colorClasses = {
    github: 'from-accent-github/20 to-accent-github/5 border-accent-github/30',
    collective: 'from-accent-collective/20 to-accent-collective/5 border-accent-collective/30',
    default: 'from-gray-700/20 to-gray-700/5 border-gray-700/30',
  };

  const iconColorClasses = {
    github: 'text-accent-github',
    collective: 'text-accent-collective',
    default: 'text-gray-400',
  };

  return (
    <div className={`bg-gradient-to-br rounded-xl p-6 border card-hover transition-all duration-200 ${colorClasses[color]}`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm text-gray-400 font-medium">{title}</p>
          <p className="mt-2 text-3xl font-bold text-white">{value}</p>
          {subtitle && (
            <p className="mt-1 text-sm text-gray-500">{subtitle}</p>
          )}
          {trend && (
            <div className="mt-3 flex items-center space-x-1">
              <span className={trend.value >= 0 ? 'text-accent-collective' : 'text-red-400'}>
                {trend.value >= 0 ? '+' : ''}{trend.value}%
              </span>
              <span className="text-gray-500 text-sm">{trend.label}</span>
            </div>
          )}
        </div>
        <div className={iconColorClasses[color]}>{icon}</div>
      </div>
    </div>
  );
}
