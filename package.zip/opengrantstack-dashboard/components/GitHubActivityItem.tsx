import React from 'react';
import { GitHubEvent } from '@/types';

interface GitHubActivityItemProps {
  event: GitHubEvent;
}

export default function GitHubActivityItem({ event }: GitHubActivityItemProps) {
  const getEventIcon = () => {
    switch (event.type) {
      case 'push':
        return (
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
          </svg>
        );
      case 'pull_request':
        return (
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
          </svg>
        );
      case 'issue':
        return (
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        );
      default:
        return (
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        );
    }
  };

  const getEventDescription = () => {
    switch (event.type) {
      case 'push':
        const commitCount = event.payload.commits?.length || 1;
        return (
          <span>
            Pushed {commitCount} {commitCount === 1 ? 'commit' : 'commits'} to{' '}
            <span className="text-accent-github font-mono text-sm">{event.repo.name}</span>
          </span>
        );
      case 'pull_request':
        const pr = event.payload.pull_request;
        return (
          <span>
            {pr?.merged ? 'Merged' : pr?.state === 'open' ? 'Opened' : 'Closed'} PR{' '}
            <a
              href={pr?.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-accent-github hover:underline font-mono text-sm"
            >
              #{pr?.number}
            </a>
            : {pr?.title}
          </span>
        );
      case 'issue':
        const issue = event.payload.issue;
        return (
          <span>
            {event.payload.action === 'opened' ? 'Opened' : 'Closed'} issue{' '}
            <a
              href={issue?.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-accent-github hover:underline font-mono text-sm"
            >
              #{issue?.number}
            </a>
            : {issue?.title}
          </span>
        );
      default:
        return <span>Performed {event.type} action</span>;
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="flex items-start space-x-3 p-4 hover:bg-primary-800/50 rounded-lg transition-colors">
      <img
        src={event.actor.avatar_url}
        alt={event.actor.login}
        className="w-8 h-8 rounded-full flex-shrink-0"
      />
      <div className="flex-1 min-w-0">
        <div className="flex items-center space-x-2">
          <span className="font-medium text-white">{event.actor.login}</span>
          <span className="text-gray-500">•</span>
          <span className="text-gray-400 text-sm">{formatTime(event.created_at)}</span>
        </div>
        <p className="text-sm text-gray-300 mt-1">{getEventDescription()}</p>
        {event.payload.commits && event.payload.commits.length > 0 && (
          <div className="mt-2 pl-3 border-l-2 border-primary-700">
            <p className="text-xs text-gray-500 font-mono truncate">
              {event.payload.commits[0].message}
            </p>
          </div>
        )}
      </div>
      <div className="text-gray-500 flex-shrink-0">{getEventIcon()}</div>
    </div>
  );
}
