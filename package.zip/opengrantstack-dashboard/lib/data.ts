import { GitHubEvent, OpenCollectiveEvent, WebhookLog, ProjectStats } from '@/types';

// In-memory data store for demo purposes
// In production, replace with a database (PostgreSQL, MongoDB, etc.)

let githubEvents: GitHubEvent[] = [
  {
    id: '1',
    type: 'push',
    actor: {
      login: 'dev1',
      avatar_url: 'https://avatars.githubusercontent.com/u/1?v=4',
    },
    repo: {
      name: 'OpenGrantStack',
      full_name: 'OpenGrantStack/OpenGrantStack',
      url: 'https://github.com/OpenGrantStack/OpenGrantStack',
    },
    payload: {
      commits: [
        {
          id: 'abc123',
          message: 'Initial commit: Setup project structure',
          url: 'https://github.com/OpenGrantStack/OpenGrantStack/commit/abc123',
        },
      ],
    },
    created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
  {
    id: '2',
    type: 'pull_request',
    actor: {
      login: 'contributor1',
      avatar_url: 'https://avatars.githubusercontent.com/u/2?v=4',
    },
    repo: {
      name: 'OpenGrantStack',
      full_name: 'OpenGrantStack/OpenGrantStack',
      url: 'https://github.com/OpenGrantStack/OpenGrantStack',
    },
    payload: {
      pull_request: {
        number: 42,
        title: 'Add webhook integration support',
        url: 'https://github.com/OpenGrantStack/OpenGrantStack/pull/42',
        state: 'open',
        merged: false,
      },
    },
    created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
  },
  {
    id: '3',
    type: 'issue',
    actor: {
      login: 'maintainer1',
      avatar_url: 'https://avatars.githubusercontent.com/u/3?v=4',
    },
    repo: {
      name: 'OpenGrantStack',
      full_name: 'OpenGrantStack/OpenGrantStack',
      url: 'https://github.com/OpenGrantStack/OpenGrantStack',
    },
    payload: {
      issue: {
        number: 15,
        title: 'Implement Open Collective sync',
        url: 'https://github.com/OpenGrantStack/OpenGrantStack/issues/15',
        state: 'open',
      },
      action: 'opened',
    },
    created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
];

let collectiveEvents: OpenCollectiveEvent[] = [
  {
    id: 'oc1',
    type: 'transaction',
    collective: {
      slug: 'opengrantstack-collection',
      name: 'OpenGrantStack Collection',
      url: 'https://opencollective.com/opengrantstack-collection',
    },
    data: {
      amount: 500,
      currency: 'USD',
      description: 'Monthly sponsorship',
      type: 'credit',
      status: 'paid',
      fromCollective: {
        name: 'Tech Foundation',
        slug: 'tech-foundation',
      },
    },
    createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
  },
  {
    id: 'oc2',
    type: 'expense',
    collective: {
      slug: 'opengrantstack-collection',
      name: 'OpenGrantStack Collection',
      url: 'https://opencollective.com/opengrantstack-collection',
    },
    data: {
      amount: 250,
      currency: 'USD',
      description: 'Server costs - December 2024',
      type: 'debit',
      status: 'approved',
      expense: {
        id: 'exp1',
        title: 'Infrastructure expenses',
        description: 'Monthly server hosting costs',
      },
    },
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
  },
  {
    id: 'oc3',
    type: 'order',
    collective: {
      slug: 'opengrantstack-collection',
      name: 'OpenGrantStack Collection',
      url: 'https://opencollective.com/opengrantstack-collection',
    },
    data: {
      amount: 1000,
      currency: 'USD',
      description: 'Annual grant funding',
      type: 'credit',
      status: 'paid',
      fromCollective: {
        name: 'Open Source Fund',
        slug: 'open-source-fund',
      },
    },
    createdAt: new Date(Date.now() - 86400000 * 6).toISOString(),
  },
];

let webhookLogs: WebhookLog[] = [
  {
    id: 'log1',
    source: 'github',
    eventType: 'push',
    status: 'success',
    message: 'Successfully processed push event with 3 commits',
    payload: { ref: 'refs/heads/main', commits: 3 },
    timestamp: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: 'log2',
    source: 'opencollective',
    eventType: 'transaction.created',
    status: 'success',
    message: 'Transaction recorded: $500.00 USD',
    payload: { amount: 500, currency: 'USD' },
    timestamp: new Date(Date.now() - 7200000).toISOString(),
  },
  {
    id: 'log3',
    source: 'github',
    eventType: 'pull_request',
    status: 'success',
    message: 'Pull request #42 opened',
    payload: { action: 'opened', number: 42 },
    timestamp: new Date(Date.now() - 86400000).toISOString(),
  },
];

const stats: ProjectStats = {
  github: {
    stars: 128,
    forks: 34,
    openIssues: 12,
    openPRs: 5,
    contributors: 18,
  },
  collective: {
    totalBalance: 3250,
    currency: 'USD',
    totalContributors: 47,
    totalTransactions: 156,
  },
};

// Data access functions
export function getGitHubEvents(): GitHubEvent[] {
  return [...githubEvents].sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );
}

export function addGitHubEvent(event: GitHubEvent): void {
  githubEvents = [event, ...githubEvents];
  // Keep only last 100 events
  if (githubEvents.length > 100) {
    githubEvents = githubEvents.slice(0, 100);
  }
}

export function getCollectiveEvents(): OpenCollectiveEvent[] {
  return [...collectiveEvents].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export function addCollectiveEvent(event: OpenCollectiveEvent): void {
  collectiveEvents = [event, ...collectiveEvents];
  // Keep only last 100 events
  if (collectiveEvents.length > 100) {
    collectiveEvents = collectiveEvents.slice(0, 100);
  }
}

export function getWebhookLogs(): WebhookLog[] {
  return [...webhookLogs].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

export function addWebhookLog(log: WebhookLog): void {
  webhookLogs = [log, ...webhookLogs];
  // Keep only last 50 logs
  if (webhookLogs.length > 50) {
    webhookLogs = webhookLogs.slice(0, 50);
  }
}

export function getStats(): ProjectStats {
  return { ...stats };
}

export function updateCollectiveBalance(amount: number): void {
  stats.collective.totalBalance += amount;
  stats.collective.totalTransactions += 1;
}

export function updateGitHubStats(update: Partial<ProjectStats['github']>): void {
  Object.assign(stats.github, update);
}
