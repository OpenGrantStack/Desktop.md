import { chromium } from 'playwright';

async function testDashboard() {
  console.log('Starting browser test...');
  
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();
  
  // Collect console messages
  const consoleMessages: string[] = [];
  page.on('console', (msg) => {
    consoleMessages.push(`[${msg.type()}] ${msg.text()}`);
  });
  
  // Collect page errors
  const pageErrors: string[] = [];
  page.on('pageerror', (error) => {
    pageErrors.push(error.message);
  });
  
  try {
    // Navigate to the dashboard
    console.log('Navigating to http://localhost:3000...');
    await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
    
    // Check if page loaded successfully
    const title = await page.title();
    console.log(`Page title: ${title}`);
    
    // Verify key elements exist
    console.log('Checking key elements...');
    
    // Check header
    const header = await page.$('header');
    console.log(`Header found: ${header !== null}`);
    
    // Check GitHub link
    const githubLink = await page.$('a[href="https://github.com/OpenGrantStack"]');
    console.log(`GitHub link found: ${githubLink !== null}`);
    
    // Check Open Collective link
    const ocLink = await page.$('a[href="https://opencollective.com/opengrantstack-collection"]');
    console.log(`Open Collective link found: ${ocLink !== null}`);
    
    // Check stats cards
    const statCards = await page.$$('.bg-gradient-to-br.rounded-xl');
    console.log(`Stat cards found: ${statCards.length}`);
    
    // Check webhook endpoints documentation page
    console.log('Testing API docs page...');
    await page.goto('http://localhost:3000/api/docs', { waitUntil: 'networkidle' });
    const docsTitle = await page.title();
    console.log(`API Docs title: ${docsTitle}`);
    
    // Print console messages
    console.log('\n--- Console Messages ---');
    consoleMessages.forEach((msg) => console.log(msg));
    
    // Print page errors
    if (pageErrors.length > 0) {
      console.log('\n--- Page Errors ---');
      pageErrors.forEach((error) => console.log(`ERROR: ${error}`));
      process.exit(1);
    } else {
      console.log('\n✓ No page errors detected');
    }
    
    console.log('\n✓ All tests passed!');
    
  } catch (error) {
    console.error('Test failed:', error);
    process.exit(1);
  } finally {
    await browser.close();
  }
}

testDashboard();
