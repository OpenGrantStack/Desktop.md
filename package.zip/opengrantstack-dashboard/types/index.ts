export interface GitHubEvent {
  id: string;
  type: 'push' | 'pull_request' | 'issue' | 'fork' | 'star';
  actor: {
    login: string;
    avatar_url: string;
  };
  repo: {
    name: string;
    full_name: string;
    url: string;
  };
  payload: {
    commits?: Array<{
      id: string;
      message: string;
      url: string;
    }>;
    pull_request?: {
      number: number;
      title: string;
      url: string;
      state: 'open' | 'closed' | 'merged';
      merged: boolean;
    };
    issue?: {
      number: number;
      title: string;
      url: string;
      state: 'open' | 'closed';
    };
    action?: string;
  };
  created_at: string;
}

export interface OpenCollectiveEvent {
  id: string;
  type: 'transaction' | 'expense' | 'member' | 'order';
  collective: {
    slug: string;
    name: string;
    url: string;
  };
  data: {
    amount?: number;
    currency?: string;
    description?: string;
    type?: 'credit' | 'debit';
    status?: 'pending' | 'paid' | 'approved' | 'rejected';
    fromCollective?: {
      name: string;
      slug: string;
    };
    usingVirtualCard?: boolean;
    expense?: {
      id: string;
      title: string;
      description: string;
    };
  };
  createdAt: string;
}

export interface WebhookLog {
  id: string;
  source: 'github' | 'opencollective' | 'custom';
  eventType: string;
  status: 'success' | 'error';
  message: string;
  payload: Record<string, unknown>;
  timestamp: string;
}

export interface ProjectStats {
  github: {
    stars: number;
    forks: number;
    openIssues: number;
    openPRs: number;
    contributors: number;
  };
  collective: {
    totalBalance: number;
    currency: string;
    totalContributors: number;
    totalTransactions: number;
  };
}

export interface DashboardData {
  githubEvents: GitHubEvent[];
  collectiveEvents: OpenCollectiveEvent[];
  webhookLogs: WebhookLog[];
  stats: ProjectStats;
}
