# OpenGrantStack Dashboard

A comprehensive dashboard for OpenGrantStack that integrates GitHub contributions with Open Collective financial tracking, featuring real-time webhook support.

## Features

- **GitHub Integration**: Track pushes, pull requests, issues, forks, and stars in real-time
- **Open Collective Integration**: Monitor transactions, expenses, and member activity
- **Webhook Support**: Working endpoints for GitHub, Open Collective, and custom webhooks
- **Live Dashboard**: Real-time visualization of project activity and finances
- **Custom Domain**: Ready for deployment at opengrantstack.publicvm.com

## Tech Stack

- **Framework**: Next.js 14 with TypeScript
- **Styling**: Tailwind CSS
- **Deployment**: Vercel (recommended)
- **Webhook Security**: HMAC SHA256 signature verification

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/OpenGrantStack/OpenGrantStack.git
cd OpenGrantStack

# Install dependencies
npm install

# Copy environment variables
cp .env.local.example .env.local

# Start development server
npm run dev
```

### Environment Variables

Configure the following environment variables in `.env.local`:

```env
# GitHub Webhook Secret (for signature verification)
GITHUB_WEBHOOK_SECRET=your_github_webhook_secret_here

# Open Collective Configuration
OPENCOLLECTIVE_WEBHOOK_SECRET=your_opencollective_webhook_secret_here
NEXT_PUBLIC_OPENCOLLECTIVE_SLUG=opengrantstack-collection

# GitHub Configuration
NEXT_PUBLIC_GITHUB_OWNER=OpenGrantStack
NEXT_PUBLIC_GITHUB_REPO=OpenGrantStack
```

## Webhook Endpoints

### GitHub Webhooks

**Endpoint**: `POST /api/webhooks/github`

**Events Supported**:
- `push` - Code commits
- `pull_request` - PR opened, closed, merged
- `issues` - Issue opened, closed
- `fork` - Repository forked
- `watch` - Star added

**Required Headers**:
- `X-Hub-Signature-256` - HMAC SHA256 signature
- `X-GitHub-Event` - Event type
- `X-GitHub-Delivery` - Unique delivery ID

### Open Collective Webhooks

**Endpoint**: `POST /api/webhooks/opencollective`

**Events Supported**:
- `transaction.created` - New transaction
- `order.created` - New order/sponsorship
- `expense.created` - New expense
- `expense.approved` - Expense approved
- `member.created` - New member

**Required Headers**:
- `X-OC-Signature` - HMAC SHA256 signature
- `X-OC-Event` - Event type

### Custom Webhooks

**Endpoint**: `POST /api/webhooks/custom`

Receive custom webhook events from any application.

**Required Headers**:
- `Content-Type: application/json`

**Request Body**:
```json
{
  "source": "my-application",
  "type": "custom.event",
  "data": {
    "key": "value"
  }
}
```

## Deployment

### Vercel (Recommended)

1. Push your code to a GitHub repository
2. Import the project in Vercel
3. Add environment variables in Vercel dashboard
4. Add custom domain: `opengrantstack.publicvm.com`
5. Deploy

### Custom Domain Setup

To configure `opengrantstack.publicvm.com`:

1. In Vercel: Settings → Domains → Add Domain
2. In your DNS provider (publicvm.com):
   - Add CNAME record: `opengrantstack.publicvm.com → cname.vercel-dns.com`
   - Or A record: `opengrantstack.publicvm.com → 76.76.21.21`

### GitHub Webhook Setup

1. Go to Repository Settings → Webhooks → Add webhook
2. Payload URL: `https://opengrantstack.publicvm.com/api/webhooks/github`
3. Content type: `application/json`
4. Secret: Your `GITHUB_WEBHOOK_SECRET` value
5. Select events: Push, Pull requests, Issues, Fork, Watch

### Open Collective Webhook Setup

1. Go to your Collective settings → Webhooks
2. Add webhook:
   - URL: `https://opengrantstack.publicvm.com/api/webhooks/opencollective`
   - Secret: Your `OPENCOLLECTIVE_WEBHOOK_SECRET` value
3. Select events: Transactions, Orders, Expenses, Members

## Project Structure

```
opengrantstack-dashboard/
├── components/
│   ├── Layout.tsx           # Main layout with header/footer
│   ├── StatCard.tsx         # Statistics display cards
│   ├── GitHubActivityItem.tsx  # GitHub event list item
│   ├── TransactionItem.tsx     # Financial transaction item
│   └── WebhookLogItem.tsx   # Webhook log entry
├── lib/
│   └── data.ts              # In-memory data store
├── pages/
│   ├── _app.tsx             # Next.js app wrapper
│   ├── _document.tsx        # HTML document wrapper
│   ├── index.tsx            # Main dashboard page
│   └── api/
│       ├── docs.tsx         # API documentation
│       └── webhooks/
│           ├── github.ts        # GitHub webhook handler
│           ├── opencollective.ts # Open Collective handler
│           └── custom.ts        # Custom webhook handler
├── styles/
│   └── globals.css          # Global styles and Tailwind
├── types/
│   └── index.ts             # TypeScript interfaces
└── package.json
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Support

- **GitHub**: https://github.com/OpenGrantStack
- **Open Collective**: https://opencollective.com/opengrantstack-collection
- **Website**: https://opengrantstack.publicvm.com
