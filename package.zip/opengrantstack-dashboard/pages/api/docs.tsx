import React from 'react';
import Layout from '@/components/Layout';

export default function ApiDocs() {
  const webhookEndpoints = [
    {
      method: 'POST',
      path: '/api/webhooks/github',
      description: 'Receive GitHub webhook events',
      events: ['push', 'pull_request', 'issues', 'fork', 'watch'],
      headers: [
        { name: 'X-Hub-Signature-256', required: true, description: 'HMAC SHA256 signature' },
        { name: 'X-GitHub-Event', required: true, description: 'Type of event' },
        { name: 'X-GitHub-Delivery', required: true, description: 'Unique delivery ID' },
      ],
    },
    {
      method: 'POST',
      path: '/api/webhooks/opencollective',
      description: 'Receive Open Collective webhook events',
      events: ['transaction.created', 'order.created', 'expense.created', 'expense.approved', 'member.created'],
      headers: [
        { name: 'X-OC-Signature', required: true, description: 'HMAC SHA256 signature' },
        { name: 'X-OC-Event', required: true, description: 'Type of event' },
      ],
    },
    {
      method: 'POST',
      path: '/api/webhooks/custom',
      description: 'Receive custom webhook events',
      events: ['Any custom event type'],
      headers: [
        { name: 'Content-Type', required: true, description: 'application/json' },
      ],
    },
  ];

  const codeExamples = {
    github: `curl -X POST https://opengrantstack.publicvm.com/api/webhooks/github \\
  -H "Content-Type: application/json" \\
  -H "X-GitHub-Event: push" \\
  -H "X-GitHub-Delivery: $(uuidgen)" \\
  -H "X-Hub-Signature-256: sha256=..." \\
  -d '{
    "action": "opened",
    "sender": {
      "login": "contributor",
      "avatar_url": "https://avatars.githubusercontent.com/u/1"
    },
    "repository": {
      "name": "OpenGrantStack",
      "full_name": "OpenGrantStack/OpenGrantStack",
      "html_url": "https://github.com/OpenGrantStack/OpenGrantStack"
    },
    "commits": [
      {
        "id": "abc123",
        "message": "Fix bug in webhook handler",
        "url": "https://github.com/..."
      }
    ]
  }'`,

    opencollective: `curl -X POST https://opengrantstack.publicvm.com/api/webhooks/opencollective \\
  -H "Content-Type: application/json" \\
  -H "X-OC-Event: transaction.created" \\
  -H "X-OC-Signature: sha256=..." \\
  -d '{
    "type": "transaction.created",
    "collective": {
      "slug": "opengrantstack-collection",
      "name": "OpenGrantStack Collection",
      "url": "https://opencollective.com/opengrantstack-collection"
    },
    "data": {
      "amount": 500,
      "currency": "USD",
      "description": "Monthly sponsorship",
      "type": "credit",
      "status": "paid",
      "fromCollective": {
        "name": "Tech Foundation",
        "slug": "tech-foundation"
      }
    }
  }'`,

    custom: `curl -X POST https://opengrantstack.publicvm.com/api/webhooks/custom \\
  -H "Content-Type: application/json" \\
  -d '{
    "source": "my-app",
    "type": "user.signed_up",
    "data": {
      "userId": "12345",
      "email": "user@example.com",
      "plan": "premium"
    }
  }'`,
  };

  return (
    <Layout title="API Documentation - OpenGrantStack">
      {/* Header */}
      <div className="bg-gradient-to-b from-primary-800 to-primary-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-4 mb-6">
            <svg className="w-10 h-10 text-accent-github" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <h1 className="text-4xl font-bold text-white">API Documentation</h1>
          </div>
          <p className="text-xl text-gray-400 max-w-3xl">
            Complete reference for OpenGrantStack webhook endpoints. Connect your applications
            to receive real-time updates from GitHub and Open Collective.
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="py-16 bg-primary-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Webhook Endpoints */}
          <section className="mb-16">
            <h2 className="text-2xl font-bold text-white mb-8">Webhook Endpoints</h2>
            <div className="space-y-6">
              {webhookEndpoints.map((endpoint, index) => (
                <div
                  key={index}
                  className="bg-primary-800 rounded-xl border border-primary-700 overflow-hidden"
                >
                  <div className="p-6 border-b border-primary-700">
                    <div className="flex items-center space-x-4">
                      <span className="px-3 py-1 bg-accent-collective/20 text-accent-collective text-sm font-mono font-semibold rounded">
                        {endpoint.method}
                      </span>
                      <code className="text-accent-github font-mono text-lg">
                        {endpoint.path}
                      </code>
                    </div>
                    <p className="text-gray-400 mt-2">{endpoint.description}</p>
                  </div>
                  <div className="p-6">
                    <h4 className="text-sm font-semibold text-gray-300 mb-3">Supported Events</h4>
                    <div className="flex flex-wrap gap-2 mb-6">
                      {endpoint.events.map((event, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 bg-primary-700 text-gray-300 text-sm font-mono rounded"
                        >
                          {event}
                        </span>
                      ))}
                    </div>
                    <h4 className="text-sm font-semibold text-gray-300 mb-3">Required Headers</h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="text-left text-gray-500 border-b border-primary-700">
                            <th className="pb-2 font-medium">Header</th>
                            <th className="pb-2 font-medium">Required</th>
                            <th className="pb-2 font-medium">Description</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-primary-700">
                          {endpoint.headers.map((header, i) => (
                            <tr key={i}>
                              <td className="py-2 font-mono text-accent-github">{header.name}</td>
                              <td className="py-2">
                                {header.required ? (
                                  <span className="text-red-400">Yes</span>
                                ) : (
                                  <span className="text-gray-500">No</span>
                                )}
                              </td>
                              <td className="py-2 text-gray-400">{header.description}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Code Examples */}
          <section className="mb-16">
            <h2 className="text-2xl font-bold text-white mb-8">Usage Examples</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {Object.entries(codeExamples).map(([name, code]) => (
                <div key={name} className="bg-primary-800 rounded-xl border border-primary-700 overflow-hidden">
                  <div className="p-4 border-b border-primary-700">
                    <h3 className="font-semibold text-white capitalize">{name} Webhook</h3>
                  </div>
                  <div className="p-4 bg-primary-900">
                    <pre className="text-xs text-gray-300 font-mono overflow-x-auto whitespace-pre-wrap">
                      {code}
                    </pre>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Security */}
          <section className="mb-16">
            <h2 className="text-2xl font-bold text-white mb-8">Security</h2>
            <div className="bg-primary-800 rounded-xl border border-primary-700 p-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-6 h-6 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Webhook Verification</h3>
                  <p className="text-gray-400 mb-4">
                    All webhook endpoints support HMAC SHA256 signature verification. To enable
                    verification, set the following environment variables:
                  </p>
                  <div className="bg-primary-900 rounded-lg p-4 font-mono text-sm">
                    <p className="text-gray-500"># For GitHub</p>
                    <p className="text-accent-github">GITHUB_WEBHOOK_SECRET=your_secret_here</p>
                    <p className="text-gray-500 mt-2"># For Open Collective</p>
                    <p className="text-accent-collective">OPENCOLLECTIVE_WEBHOOK_SECRET=your_secret_here</p>
                  </div>
                  <p className="text-gray-400 mt-4">
                    Requests without a valid signature will be rejected with a 401 status code.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Response Format */}
          <section>
            <h2 className="text-2xl font-bold text-white mb-8">Response Format</h2>
            <div className="bg-primary-800 rounded-xl border border-primary-700 p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Success Response</h3>
              <div className="bg-primary-900 rounded-lg p-4 mb-6">
                <pre className="text-sm text-gray-300 font-mono overflow-x-auto">
{`{
  "success": true,
  "eventId": "gh-abc123-def456",
  "message": "Webhook received successfully"
}`}
                </pre>
              </div>
              <h3 className="text-lg font-semibold text-white mb-4">Error Response</h3>
              <div className="bg-primary-900 rounded-lg p-4">
                <pre className="text-sm text-gray-300 font-mono overflow-x-auto">
{`{
  "error": "Invalid signature"
}`}
                </pre>
              </div>
            </div>
          </section>
        </div>
      </div>
    </Layout>
  );
}
