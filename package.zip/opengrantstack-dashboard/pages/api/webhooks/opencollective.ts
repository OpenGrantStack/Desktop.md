import type { NextApiRequest, NextApiResponse } from 'next';
import crypto from 'crypto';
import {
  addCollectiveEvent,
  addWebhookLog,
  updateCollectiveBalance,
} from '@/lib/data';
import { OpenCollectiveEvent } from '@/types';

interface OpenCollectiveWebhookPayload {
  type?: string;
  action?: string;
  collective?: {
    slug: string;
    name: string;
    url: string;
  };
  data?: {
    amount?: number;
    currency?: string;
    description?: string;
    type?: 'credit' | 'debit';
    status?: 'pending' | 'paid' | 'approved' | 'rejected';
    fromCollective?: {
      name: string;
      slug: string;
    };
    order?: {
      id: string;
      totalAmount: number;
      currency: string;
    };
    expense?: {
      id: string;
      title: string;
      description: string;
    };
    transaction?: {
      id: string;
      amount: number;
      currency: string;
    };
  };
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const signature = req.headers['x-oc-signature'] as string;
  const eventType = req.headers['x-oc-event'] as string;

  // Verify webhook secret (in production, use OPENCOLLECTIVE_WEBHOOK_SECRET from env)
  const webhookSecret = process.env.OPENCOLLECTIVE_WEBHOOK_SECRET;

  if (webhookSecret) {
    const isVerified = verifyOpenCollectiveSignature(
      JSON.stringify(req.body),
      signature,
      webhookSecret
    );

    if (!isVerified) {
      console.error('Invalid Open Collective webhook signature');
      addWebhookLog({
        id: `log-${Date.now()}`,
        source: 'opencollective',
        eventType: eventType || 'unknown',
        status: 'error',
        message: 'Invalid webhook signature - unauthorized request',
        payload: {},
        timestamp: new Date().toISOString(),
      });
      return res.status(401).json({ error: 'Invalid signature' });
    }
  }

  try {
    const payload: OpenCollectiveWebhookPayload = req.body;

    // Map Open Collective event to our event format
    const event = mapOpenCollectiveEvent(payload, eventType);

    if (event) {
      addCollectiveEvent(event);

      // Update balance if this is a transaction
      if (
        event.data.amount &&
        event.data.status === 'paid' &&
        event.type !== 'expense'
      ) {
        updateCollectiveBalance(event.data.type === 'credit' ? event.data.amount : -event.data.amount);
      }
    }

    // Log successful webhook processing
    addWebhookLog({
      id: `log-${Date.now()}`,
      source: 'opencollective',
      eventType: eventType || 'unknown',
      status: 'success',
      message: `Successfully processed ${eventType} event${event ? ` from ${event.data.fromCollective?.name || 'Anonymous'}` : ''}`,
      payload: {
        amount: event?.data.amount,
        currency: event?.data.currency,
        type: event?.data.type,
      },
      timestamp: new Date().toISOString(),
    });

    return res.status(200).json({ success: true, eventId: event?.id });
  } catch (error) {
    console.error('Error processing Open Collective webhook:', error);

    addWebhookLog({
      id: `log-${Date.now()}`,
      source: 'opencollective',
      eventType: eventType || 'unknown',
      status: 'error',
      message: `Error processing webhook: ${error instanceof Error ? error.message : 'Unknown error'}`,
      payload: {},
      timestamp: new Date().toISOString(),
    });

    return res.status(500).json({ error: 'Internal server error' });
  }
}

function verifyOpenCollectiveSignature(
  payload: string,
  signature: string,
  secret: string
): boolean {
  if (!signature) return false;

  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');

  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}

function mapOpenCollectiveEvent(
  payload: OpenCollectiveWebhookPayload,
  eventType: string
): OpenCollectiveEvent | null {
  const collectiveSlug = payload.collective?.slug || 'opengrantstack-collection';

  // Handle different event types
  if (eventType === 'transaction.created' || eventType === 'order.created') {
    const orderData = payload.data?.order;
    const transactionData = payload.data?.transaction;

    return {
      id: `oc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'transaction',
      collective: {
        slug: collectiveSlug,
        name: payload.collective?.name || 'OpenGrantStack Collection',
        url: payload.collective?.url || 'https://opencollective.com/opengrantstack-collection',
      },
      data: {
        amount: orderData?.totalAmount || transactionData?.amount || 0,
        currency: orderData?.currency || transactionData?.currency || 'USD',
        description: payload.data?.description || 'Transaction',
        type: 'credit',
        status: 'paid',
        fromCollective: payload.data?.fromCollective,
      },
      createdAt: new Date().toISOString(),
    };
  }

  if (eventType === 'expense.created' || eventType === 'expense.approved') {
    return {
      id: `oc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'expense',
      collective: {
        slug: collectiveSlug,
        name: payload.collective?.name || 'OpenGrantStack Collection',
        url: payload.collective?.url || 'https://opencollective.com/opengrantstack-collection',
      },
      data: {
        amount: payload.data?.amount || 0,
        currency: payload.data?.currency || 'USD',
        description: payload.data?.expense?.title || 'Expense',
        type: 'debit',
        status: eventType === 'expense.approved' ? 'approved' : 'pending',
        expense: {
          id: payload.data?.expense?.id || '',
          title: payload.data?.expense?.title || '',
          description: payload.data?.expense?.description || '',
        },
      },
      createdAt: new Date().toISOString(),
    };
  }

  if (eventType === 'member.created') {
    return {
      id: `oc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'member',
      collective: {
        slug: collectiveSlug,
        name: payload.collective?.name || 'OpenGrantStack Collection',
        url: payload.collective?.url || 'https://opencollective.com/opengrantstack-collection',
      },
      data: {
        description: `New member: ${payload.data?.fromCollective?.name || 'Anonymous'}`,
        fromCollective: payload.data?.fromCollective,
      },
      createdAt: new Date().toISOString(),
    };
  }

  // Generic event mapping
  return {
    id: `oc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    type: 'transaction',
    collective: {
      slug: collectiveSlug,
      name: payload.collective?.name || 'OpenGrantStack Collection',
      url: payload.collective?.url || 'https://opencollective.com/opengrantstack-collection',
    },
    data: {
      amount: payload.data?.amount || 0,
      currency: payload.data?.currency || 'USD',
      description: payload.data?.description || eventType,
      type: payload.data?.type || 'credit',
      status: payload.data?.status || 'pending',
      fromCollective: payload.data?.fromCollective,
    },
    createdAt: new Date().toISOString(),
  };
}
