import type { NextApiRequest, NextApiResponse } from 'next';
import crypto from 'crypto';
import { addGitHubEvent, addWebhookLog, updateGitHubStats } from '@/lib/data';
import { GitHubEvent } from '@/types';

interface GitHubWebhookPayload {
  id?: string;
  type?: string;
  action?: string;
  sender?: {
    login: string;
    avatar_url: string;
  };
  repository?: {
    name: string;
    full_name: string;
    html_url: string;
  };
  commits?: Array<{
    id: string;
    message: string;
    url: string;
  }>;
  pull_request?: {
    number: number;
    title: string;
    html_url: string;
    state: string;
    merged: boolean;
  };
  issue?: {
    number: number;
    title: string;
    html_url: string;
    state: string;
  };
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const signature = req.headers['x-hub-signature-256'] as string;
  const eventType = req.headers['x-github-event'] as string;
  const deliveryId = req.headers['x-github-delivery'] as string;

  // Verify webhook secret (in production, use GITHUB_WEBHOOK_SECRET from env)
  const webhookSecret = process.env.GITHUB_WEBHOOK_SECRET;
  
  if (webhookSecret) {
    const isVerified = verifyGitHubSignature(
      JSON.stringify(req.body),
      signature,
      webhookSecret
    );

    if (!isVerified) {
      console.error('Invalid GitHub webhook signature');
      addWebhookLog({
        id: `log-${Date.now()}`,
        source: 'github',
        eventType: eventType || 'unknown',
        status: 'error',
        message: 'Invalid webhook signature - unauthorized request',
        payload: { deliveryId },
        timestamp: new Date().toISOString(),
      });
      return res.status(401).json({ error: 'Invalid signature' });
    }
  }

  try {
    const payload: GitHubWebhookPayload = req.body;

    // Map GitHub event to our event format
    const event = mapGitHubEvent(payload, eventType);

    if (event) {
      addGitHubEvent(event);

      // Update stats based on event type
      if (event.type === 'fork') {
        updateGitHubStats({ forks: 1 });
      } else if (event.type === 'push' && payload.commits) {
        // Could update commit count here
      }
    }

    // Log successful webhook processing
    addWebhookLog({
      id: `log-${Date.now()}`,
      source: 'github',
      eventType: eventType || 'unknown',
      status: 'success',
      message: `Successfully processed ${eventType} event${event ? ` from ${event.actor.login}` : ''}`,
      payload: {
        deliveryId,
        action: payload.action,
        repository: payload.repository?.full_name,
      },
      timestamp: new Date().toISOString(),
    });

    return res.status(200).json({ success: true, eventId: event?.id });
  } catch (error) {
    console.error('Error processing GitHub webhook:', error);

    addWebhookLog({
      id: `log-${Date.now()}`,
      source: 'github',
      eventType: eventType || 'unknown',
      status: 'error',
      message: `Error processing webhook: ${error instanceof Error ? error.message : 'Unknown error'}`,
      payload: { deliveryId },
      timestamp: new Date().toISOString(),
    });

    return res.status(500).json({ error: 'Internal server error' });
  }
}

function verifyGitHubSignature(
  payload: string,
  signature: string,
  secret: string
): boolean {
  if (!signature) return false;

  const expectedSignature = 'sha256=' + crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');

  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}

function mapGitHubEvent(
  payload: GitHubWebhookPayload,
  eventType: string
): GitHubEvent | null {
  const eventMap: Record<string, () => GitHubEvent | null> = {
    push: () => {
      if (!payload.commits || payload.commits.length === 0) return null;

      return {
        id: `gh-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type: 'push',
        actor: {
          login: payload.sender?.login || 'unknown',
          avatar_url: payload.sender?.avatar_url || '',
        },
        repo: {
          name: payload.repository?.name || 'unknown',
          full_name: payload.repository?.full_name || 'unknown',
          url: payload.repository?.html_url || '',
        },
        payload: {
          commits: payload.commits.map((commit) => ({
            id: commit.id,
            message: commit.message,
            url: commit.url,
          })),
        },
        created_at: new Date().toISOString(),
      };
    },
    pull_request: () => {
      if (!payload.pull_request) return null;

      return {
        id: `gh-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type: 'pull_request',
        actor: {
          login: payload.sender?.login || 'unknown',
          avatar_url: payload.sender?.avatar_url || '',
        },
        repo: {
          name: payload.repository?.name || 'unknown',
          full_name: payload.repository?.full_name || 'unknown',
          url: payload.repository?.html_url || '',
        },
        payload: {
          pull_request: {
            number: payload.pull_request.number,
            title: payload.pull_request.title,
            url: payload.pull_request.html_url,
            state: payload.pull_request.state as 'open' | 'closed' | 'merged',
            merged: payload.pull_request.merged,
          },
          action: payload.action,
        },
        created_at: new Date().toISOString(),
      };
    },
    issues: () => {
      if (!payload.issue) return null;

      return {
        id: `gh-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type: 'issue',
        actor: {
          login: payload.sender?.login || 'unknown',
          avatar_url: payload.sender?.avatar_url || '',
        },
        repo: {
          name: payload.repository?.name || 'unknown',
          full_name: payload.repository?.full_name || 'unknown',
          url: payload.repository?.html_url || '',
        },
        payload: {
          issue: {
            number: payload.issue.number,
            title: payload.issue.title,
            url: payload.issue.html_url,
            state: payload.issue.state as 'open' | 'closed',
          },
          action: payload.action,
        },
        created_at: new Date().toISOString(),
      };
    },
    fork: () => ({
      id: `gh-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'fork',
      actor: {
        login: payload.sender?.login || 'unknown',
        avatar_url: payload.sender?.avatar_url || '',
      },
      repo: {
        name: payload.repository?.name || 'unknown',
        full_name: payload.repository?.full_name || 'unknown',
        url: payload.repository?.html_url || '',
      },
      payload: {},
      created_at: new Date().toISOString(),
    }),
    watch: () => ({
      id: `gh-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'star',
      actor: {
        login: payload.sender?.login || 'unknown',
        avatar_url: payload.sender?.avatar_url || '',
      },
      repo: {
        name: payload.repository?.name || 'unknown',
        full_name: payload.repository?.full_name || 'unknown',
        url: payload.repository?.html_url || '',
      },
      payload: {},
      created_at: new Date().toISOString(),
    }),
  };

  const mapper = eventMap[eventType];
  return mapper ? mapper() : null;
}
