import type { NextApiRequest, NextApiResponse } from 'next';
import { addWebhookLog } from '@/lib/data';
import { WebhookLog } from '@/types';

interface CustomWebhookPayload {
  source?: string;
  type?: string;
  data?: Record<string, unknown>;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const payload: CustomWebhookPayload = req.body;

    // Validate required fields
    if (!payload.type) {
      return res.status(400).json({ error: 'Missing required field: type' });
    }

    // Create webhook log entry
    const log: WebhookLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      source: 'custom',
      eventType: payload.type,
      status: 'success',
      message: `Custom webhook received: ${payload.type}${payload.source ? ` from ${payload.source}` : ''}`,
      payload: payload.data || {},
      timestamp: new Date().toISOString(),
    };

    addWebhookLog(log);

    // You can add custom processing logic here based on the event type
    // For example:
    // - Sync with external services
    // - Update databases
    // - Send notifications
    // - Trigger workflows

    console.log(`Custom webhook received: ${payload.type}`, payload);

    return res.status(200).json({
      success: true,
      eventId: log.id,
      message: 'Webhook received successfully',
    });
  } catch (error) {
    console.error('Error processing custom webhook:', error);

    addWebhookLog({
      id: `log-${Date.now()}`,
      source: 'custom',
      eventType: 'error',
      status: 'error',
      message: `Error processing webhook: ${error instanceof Error ? error.message : 'Unknown error'}`,
      payload: {},
      timestamp: new Date().toISOString(),
    });

    return res.status(500).json({ error: 'Internal server error' });
  }
}
