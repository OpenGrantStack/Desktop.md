import React from 'react';
import { GetServerSideProps } from 'next';
import Layout from '@/components/Layout';
import StatCard from '@/components/StatCard';
import GitHubActivityItem from '@/components/GitHubActivityItem';
import TransactionItem from '@/components/TransactionItem';
import WebhookLogItem from '@/components/WebhookLogItem';
import {
  getGitHubEvents,
  getCollectiveEvents,
  getWebhookLogs,
  getStats,
} from '@/lib/data';
import { DashboardData } from '@/types';

interface HomePageProps {
  data: DashboardData;
}

export default function Home({ data }: HomePageProps) {
  const { githubEvents, collectiveEvents, webhookLogs, stats } = data;

  const formatCurrency = (amount: number, currency: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
    }).format(amount);
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-primary-800 to-primary-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              OpenGrantStack
            </h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-8">
              Transparent grant management for open source projects. Track code contributions
              and financial flows in one unified dashboard.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="https://github.com/OpenGrantStack"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-6 py-3 bg-accent-github text-white font-medium rounded-lg hover:bg-blue-600 transition-colors"
              >
                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                </svg>
                View on GitHub
              </a>
              <a
                href="https://opencollective.com/opengrantstack-collection"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-6 py-3 bg-accent-collective text-white font-medium rounded-lg hover:bg-emerald-600 transition-colors"
              >
                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                </svg>
                Support on Open Collective
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-primary-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard
              title="GitHub Stars"
              value={stats.github.stars}
              icon={
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
              }
              color="github"
              trend={{ value: 12, label: 'this month' }}
            />
            <StatCard
              title="Total Balance"
              value={formatCurrency(stats.collective.totalBalance, stats.collective.currency)}
              icon={
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              }
              color="collective"
              trend={{ value: 8, label: 'this month' }}
            />
            <StatCard
              title="Contributors"
              value={stats.github.contributors}
              subtitle={`${stats.collective.totalContributors} financial supporters`}
              icon={
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              }
              color="github"
            />
            <StatCard
              title="Open Issues"
              value={stats.github.openIssues}
              subtitle={`${stats.github.openPRs} pull requests`}
              icon={
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              }
              color="default"
            />
          </div>
        </div>
      </section>

      {/* Dashboard Content */}
      <section id="dashboard" className="py-12 bg-primary-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* GitHub Activity */}
            <div id="activity" className="bg-primary-800 rounded-xl border border-primary-700 overflow-hidden">
              <div className="p-6 border-b border-primary-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <svg className="w-6 h-6 text-accent-github" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                    </svg>
                    <h2 className="text-xl font-semibold text-white">GitHub Activity</h2>
                  </div>
                  <a
                    href="https://github.com/OpenGrantStack/OpenGrantStack"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-accent-github hover:underline"
                  >
                    View All →
                  </a>
                </div>
              </div>
              <div className="divide-y divide-primary-700">
                {githubEvents.slice(0, 5).map((event) => (
                  <GitHubActivityItem key={event.id} event={event} />
                ))}
              </div>
            </div>

            {/* Open Collective Transactions */}
            <div id="finances" className="bg-primary-800 rounded-xl border border-primary-700 overflow-hidden">
              <div className="p-6 border-b border-primary-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <svg className="w-6 h-6 text-accent-collective" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                    </svg>
                    <h2 className="text-xl font-semibold text-white">Financial Activity</h2>
                  </div>
                  <a
                    href="https://opencollective.com/opengrantstack-collection"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-accent-collective hover:underline"
                  >
                    View All →
                  </a>
                </div>
              </div>
              <div className="divide-y divide-primary-700">
                {collectiveEvents.slice(0, 5).map((event) => (
                  <TransactionItem key={event.id} event={event} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Webhook Logs Section */}
      <section id="webhooks" className="py-12 bg-primary-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-primary-800 rounded-xl border border-primary-700 overflow-hidden">
            <div className="p-6 border-b border-primary-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                  </svg>
                  <h2 className="text-xl font-semibold text-white">Webhook Activity</h2>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-400">
                  <span className="w-2 h-2 bg-accent-collective rounded-full status-indicator"></span>
                  <span>Live</span>
                </div>
              </div>
            </div>
            <div className="divide-y divide-primary-700">
              {webhookLogs.slice(0, 10).map((log) => (
                <WebhookLogItem key={log.id} log={log} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* API Documentation Section */}
      <section className="py-16 bg-primary-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Webhook Integration</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Connect your tools to OpenGrantStack using our webhook endpoints for real-time synchronization.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* GitHub Webhook */}
            <div className="bg-primary-800 rounded-xl border border-primary-700 p-6 card-hover">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-accent-github/20 rounded-lg flex items-center justify-center">
                  <svg className="w-6 h-6 text-accent-github" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-white">GitHub</h3>
              </div>
              <p className="text-gray-400 text-sm mb-4">
                Listen for push events, pull requests, and issues from your repositories.
              </p>
              <div className="bg-primary-900 rounded-lg p-3 font-mono text-xs text-gray-300 overflow-x-auto">
                POST /api/webhooks/github
              </div>
            </div>

            {/* Open Collective Webhook */}
            <div className="bg-primary-800 rounded-xl border border-primary-700 p-6 card-hover">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-accent-collective/20 rounded-lg flex items-center justify-center">
                  <svg className="w-6 h-6 text-accent-collective" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-white">Open Collective</h3>
              </div>
              <p className="text-gray-400 text-sm mb-4">
                Track transactions, expenses, and new orders in real-time.
              </p>
              <div className="bg-primary-900 rounded-lg p-3 font-mono text-xs text-gray-300 overflow-x-auto">
                POST /api/webhooks/opencollective
              </div>
            </div>

            {/* Custom Domain */}
            <div className="bg-primary-800 rounded-xl border border-primary-700 p-6 card-hover">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                  <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-white">Custom Webhooks</h3>
              </div>
              <p className="text-gray-400 text-sm mb-4">
                Send custom events from any application to this domain.
              </p>
              <div className="bg-primary-900 rounded-lg p-3 font-mono text-xs text-gray-300 overflow-x-auto">
                POST /api/webhooks/custom
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}

export const getServerSideProps: GetServerSideProps<HomePageProps> = async () => {
  const githubEvents = getGitHubEvents();
  const collectiveEvents = getCollectiveEvents();
  const webhookLogs = getWebhookLogs();
  const stats = getStats();

  return {
    props: {
      data: {
        githubEvents,
        collectiveEvents,
        webhookLogs,
        stats,
      },
    },
  };
};
